package cpu.instr.all_instrs;

import cpu.CPU_State;
import cpu.MMU;
import cpu.alu.ALU;
import memory.Memory;
import program.Log;

public class Mov implements Instruction{
    @Override
    public int exec(String eip, int opcode) {

        MMU mmu = MMU.getMMU();
        String segSelector = CPU_State.cs.read();
        String logic = segSelector + eip;
        Memory memory = Memory.getMemory();
        ALU alu = new ALU();
        if (opcode==199){
            String ins = new String(mmu.read(logic,80));
            String imm32 = ins.substring(48);
            String base = CPU_State.ebx.read();
            String displacement = ins.substring(16,48);
            memory.write(alu.add(base,displacement),32,imm32.toCharArray());
            Log.write(ins);
            return 80;
        }
        else if (opcode==139){
            String ins = new String(mmu.read(logic,48));
            String ds = CPU_State.ds.read();
            String displacement = ins.substring(16);
            String base = CPU_State.ebx.read();
            String offset = alu.add(base,displacement);
            char[] data = mmu.read(ds+offset,32);
            String reg = ins.substring(10,13);
            if (reg.equals("000"))
                CPU_State.eax.write(String.valueOf(data));
            else if (reg.equals("001"))
                CPU_State.ecx.write(String.valueOf(data));
            Log.write(ins);
        }
        else{
            String ins = new String(mmu.read(logic,48));
            String reg = ins.substring(10,13);
            String data = "";
            if (reg.equals("000"))
                data = CPU_State.eax.read();
            else if (reg.equals("001"))
                data = CPU_State.ecx.read();
            String displacement = ins.substring(16);
            String base = CPU_State.ebx.read();
            String offset = alu.add(base,displacement);
            memory.write(offset,32,data.toCharArray());
            Log.write(ins);
        }
        return 48;
    }
}
