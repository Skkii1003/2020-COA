package cpu.registers;

/**
 * 通用寄存器
 */
public class ESP extends Register {
}
