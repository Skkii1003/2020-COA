package cpu.instr.decode;

//The operand type for read and write
public enum OperandType {
    OPR_IMM, OPR_REG, OPR_MEM, OPR_CREG, OPR_SREG
}
