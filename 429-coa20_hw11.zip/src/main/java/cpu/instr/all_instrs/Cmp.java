package cpu.instr.all_instrs;

import cpu.CPU_State;
import cpu.MMU;
import cpu.alu.ALU;
import cpu.registers.EFlag;
import program.Log;
import transformer.Transformer;

public class Cmp implements Instruction{
    @Override
    public int exec(String eip, int opcode) {
        MMU mmu = MMU.getMMU();
        ALU alu = new ALU();
        EFlag eFlag = (EFlag) CPU_State.eflag;
        Transformer t = new Transformer();
        String segSelector = CPU_State.cs.read();
        String logic = segSelector + eip;
        String ins = new String(mmu.read(logic,16));
        Log.write(ins);

        String op1 = CPU_State.eax.read();
        String op2 = CPU_State.ecx.read();

        String res = alu.sub(op2,op1);
        eFlag.setZF(Integer.parseInt(t.binaryToInt(res)) == 0);
        eFlag.setSF(Integer.parseInt(t.binaryToInt(res)) < 0);
        CPU_State.eflag = eFlag;

        return 16;
    }
}
