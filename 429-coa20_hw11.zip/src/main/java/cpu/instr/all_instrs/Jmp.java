package cpu.instr.all_instrs;

import cpu.CPU_State;
import cpu.MMU;
import cpu.alu.ALU;
import program.Log;

public class Jmp implements Instruction{
    @Override
    public int exec(String eip, int opcode) {
        MMU mmu = MMU.getMMU();
        ALU alu = new ALU();
        String segSelector = CPU_State.cs.read();
        String logic = segSelector + eip;
        String ins = new String(mmu.read(logic,16));
        String offset = ins.substring(8);
        CPU_State.eip.write(alu.add(eip, offset));
        Log.write(ins);
        return 0;
    }
}
